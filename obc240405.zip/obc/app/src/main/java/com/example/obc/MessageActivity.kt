package com.example.obc

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isInvisible
import androidx.core.view.isVisible
import androidx.core.view.marginBottom
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.obc.databinding.ActivityMessageBinding
import com.example.obc.fragment.HomeFragment
import com.example.obc.model.ChatModel
import com.example.obc.model.ChatModel.Comment
import com.example.obc.model.Friend
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.*
import com.google.firebase.database.ktx.getValue
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.*
import org.w3c.dom.Text
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class MessageActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMessageBinding
    private val fireDatabase = FirebaseDatabase.getInstance().reference
    private var chatRoomUid : String? = null
    private var destinationUid : String? = null
    private var uid : String? = null
    private var recyclerView : RecyclerView? = null
    var peopleCount = 0

    @SuppressLint("SimpleDateFormat")
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMessageBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        supportActionBar?.hide()
        val sendBtn = binding.sendBtn
        val messageText = binding.messageText

        //메세지를 보낸 시간
        val time = System.currentTimeMillis()
        val dateFormat = SimpleDateFormat("MM월dd일 hh:mm")
        val curTime = dateFormat.format(Date(time)).toString()
        //

        destinationUid = intent.getStringExtra("destinationUid")
        uid = Firebase.auth.currentUser?.uid.toString()
        recyclerView = binding.messageActivityRecyclerview
        sendBtn.setOnClickListener {
            if(messageText.text.isNotEmpty()){
                val chatModel = ChatModel()

                chatModel.users.put(uid.toString(), true)
                chatModel.users.put(destinationUid!!, true)

                val comment = Comment(uid, messageText.text.toString(), curTime)
                if(chatRoomUid == null){
                    sendBtn.isEnabled = false
                    fireDatabase.child("chatrooms").push().setValue(chatModel).addOnSuccessListener {
                        //채팅방 생성
                        checkChatRoom()
                        //메세지 보내기
                        Handler().postDelayed({
                            fireDatabase.child("chatrooms").child(chatRoomUid.toString()).child("comments").push().setValue(comment)
                            messageText.text = null
                        }, 1000L)
                        Log.d("chatUidNull dest", "$destinationUid")
                    }
                }
                else{
                    fireDatabase.child("chatrooms").child(chatRoomUid.toString()).child("comments").push().setValue(comment)
                    messageText.text = null
                    Log.d("chatUidNotNull dest", "$destinationUid")
                }
            }
        }
        checkChatRoom()
    }

    private fun checkChatRoom(){
        fireDatabase.child("chatrooms").orderByChild("users/$uid").equalTo(true).addListenerForSingleValueEvent(object : ValueEventListener{
                override fun onCancelled(error: DatabaseError) {
                }
                override fun onDataChange(snapshot: DataSnapshot) {
                    for (item in snapshot.children){
                        val chatModel = item.getValue<ChatModel>()
                        if(chatModel?.users!!.containsKey(destinationUid)){
                            chatRoomUid = item.key
                            binding.sendBtn.isEnabled = true
                            recyclerView?.layoutManager = LinearLayoutManager(this@MessageActivity)
                            recyclerView?.adapter = RecyclerViewAdapter()
                        }
                    }
                }
            })
    }

    inner class RecyclerViewAdapter : RecyclerView.Adapter<RecyclerViewAdapter.MessageViewHolder>() {

        private val comments = ArrayList<Comment>()
        private var friend : Friend? = null
        init{
            fireDatabase.child("users").child(destinationUid.toString()).addListenerForSingleValueEvent(object : ValueEventListener{
                override fun onCancelled(error: DatabaseError) {
                }
                override fun onDataChange(snapshot: DataSnapshot) {
                    friend = snapshot.getValue<Friend>()
                    binding.messageScreenTop.text = friend?.friendName
                    getMessageList()
                }
            })
        }

        fun getMessageList(){
            fireDatabase.child("chatrooms").child(chatRoomUid.toString()).child("comments").addValueEventListener(object : ValueEventListener{
                override fun onCancelled(error: DatabaseError) {
                }
                override fun onDataChange(snapshot: DataSnapshot) {
                    comments.clear()
                    var readUsersMap: HashMap<String, Any> = HashMap()
                    for(data in snapshot.children){
                        var key = data.key
                        var commentOrigin =data.getValue<Comment>()!!
                        var commentModify =data.getValue<Comment>()!!
                        commentModify.readUsers?.put(uid.toString(), true)
                        readUsersMap.put(key.toString(), commentModify)
                        comments.add(commentOrigin)
                    }
                    if(comments.size>0){
                        if(!comments.get(comments.size-1).readUsers!!.containsKey(uid)){
                            fireDatabase.child("chatrooms").child(chatRoomUid.toString()).child("comments").updateChildren(readUsersMap).addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    notifyDataSetChanged() //메시지 갱신
                                    recyclerView?.scrollToPosition(comments.size - 1)     //메세지를 보낼 시 화면을 맨 밑으로 내림
                                }
                            }
                        }
                        else{
                            notifyDataSetChanged() //메시지 갱신
                            recyclerView?.scrollToPosition(comments.size - 1)
                        }
                    }
                }
            })
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
            val view : View = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)

            return MessageViewHolder(view)
        }
        @SuppressLint("RtlHardcoded")
        override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {


            if(comments[position].uid.equals(uid)) // 내 채팅
            {
                holder.messageRightContent.textSize = 13.5F
                holder.messageRightContent.text = comments[position].message
                holder.messageRightContent.setTextColor(Color.parseColor("#FFFFFFFF"))
                holder.messageRightContent.setBackgroundResource(R.drawable.message_right_chat)

                holder.userName.visibility = View.INVISIBLE
                holder.messageReadCountLeft.visibility = View.INVISIBLE
                holder.messageLeftContent.visibility = View.INVISIBLE
                holder.messageLeftArriveTime.visibility = View.INVISIBLE
                holder.layout_destination.visibility = View.INVISIBLE

                holder.userImage.visibility = View.INVISIBLE

                setReadCounter(position, holder.messageReadCountRight)

                if(comments.size-1>position){
                    if (comments[position].time.toString().substring(7) == comments[position+ 1].time.toString().substring(7) && comments[position+1].uid.equals(uid)){
                        val layoutParams = holder.layout_main.layoutParams as ViewGroup.MarginLayoutParams
                        layoutParams.bottomMargin = -49
                        holder.layout_main.layoutParams = layoutParams
                        holder.messageRightArriveTime.text = ""
                    }
                    else
                        holder.messageRightArriveTime.text = comments[position].time.toString().substring(7)
                }
                else
                    holder.messageRightArriveTime.text = comments[position].time.toString().substring(7)
            }
            else// 상대방 채팅
            {
                holder.messageLeftContent.textSize = 13.5F
                holder.messageLeftContent.text = comments[position].message
                holder.messageLeftContent.setTextColor(Color.parseColor("#FF545F71"))
                holder.messageLeftContent.setBackgroundResource(R.drawable.message_left_chat)

                setReadCounter(position,holder.messageReadCountRight)

                if(comments.size-1>position){
                    if(position == 0 || comments[position-1].uid.equals(uid) || comments[position].time.toString().substring(7) != comments[position - 1].time.toString().substring(7)){
                        holder.userName.text = friend?.friendName
                        holder.userName.visibility = View.VISIBLE
                        Glide.with(holder.itemView.context).load(friend?.friendProfileImageUrl).apply(RequestOptions().circleCrop()).into(holder.userImage)
                    }

                    if (comments[position].time.toString().substring(7) == comments[position + 1].time.toString().substring(7)&& !comments[position+1].uid.equals(uid)) {
                        val layoutParams = holder.layout_main.layoutParams as ViewGroup.MarginLayoutParams
                        layoutParams.bottomMargin = -49
                        holder.layout_main.layoutParams = layoutParams
                        holder.messageLeftArriveTime.text = ""
                    }
                    else{
                        holder.layout_destination.visibility = View.VISIBLE
                        holder.messageLeftArriveTime.text = comments[position].time.toString().substring(7)
                    }
                }
                else{ //마지막 대화인 경우
                    if(comments[position-1].uid.equals(uid)){
                        holder.userName.text = friend?.friendName
                        holder.userName.visibility = View.VISIBLE
                        Glide.with(holder.itemView.context).load(friend?.friendProfileImageUrl).apply(RequestOptions().circleCrop()).into(holder.userImage)
                        holder.messageLeftArriveTime.text = comments[position].time.toString().substring(7)
                    }
                    else{
                        holder.messageLeftArriveTime.text = comments[position].time.toString().substring(7)
                    }
                }

            }
        }

        inner class MessageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val messageLeftContent: TextView = view.findViewById(R.id.messageLeftContent)
            val messageRightContent: TextView = view.findViewById(R.id.messageRightContent)
            val userName: TextView = view.findViewById(R.id.userName)
            val userImage: ImageView = view.findViewById(R.id.userImage)
            val layout_destination: LinearLayout = view.findViewById(R.id.messageItem_layout_destination)
            val layout_main: LinearLayout = view.findViewById(R.id.messageItem_linearlayout_main)
            val messageLeftArriveTime : TextView = view.findViewById(R.id.messageLeftArriveTime)
            val messageRightArriveTime : TextView = view.findViewById(R.id.messageRightArriveTime)
            val messageReadCountLeft : TextView = view.findViewById(R.id.messageReadCountLeft)
            val messageReadCountRight : TextView = view.findViewById(R.id.messageReadCountRight)
        }

        fun setReadCounter(position: Int, textView: TextView){
            if(peopleCount==0){
                FirebaseDatabase.getInstance().getReference().child("chatrooms").child(chatRoomUid.toString()).child("users").addListenerForSingleValueEvent(object : ValueEventListener{
                    override fun onCancelled(error: DatabaseError) {
                    }
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val users= snapshot.value as Map<String, Boolean>
                        peopleCount = users.size
                        var count = peopleCount - comments[position].readUsers!!.size
                        if(count>0){
                            textView.visibility = View.VISIBLE
                            textView.text = count.toString()
                        }
                        else
                            textView.visibility = View.INVISIBLE
                    }
                })
            }
            else{
                var count = peopleCount - comments[position].readUsers!!.size
                if(count>0){
                    textView.visibility = View.VISIBLE
                    textView.text = count.toString()
                }
                else
                    textView.visibility = View.INVISIBLE
            }


        }
        override fun getItemCount(): Int {
            return comments.size
        }
    }
}